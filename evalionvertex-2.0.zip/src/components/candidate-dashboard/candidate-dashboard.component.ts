import { ChangeDetectionStrategy, Component, computed, inject, signal, effect, OnInit, AfterViewInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { CommonModule, Location, DOCUMENT, DatePipe } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { InterviewComponent } from '../interview/interview.component';
import { ChatbotComponent } from '../chatbot/chatbot.component';
import { AuthService, User } from '../../services/auth.service';
import { InterviewService, InterviewResult, InterviewTemplate, InterviewSession } from '../../services/interview.service';
import { ConfirmationDialogComponent } from '../shared/confirmation-dialog.component';
import { ThemeService } from '../../services/theme.service';
import { ThemeCustomizerComponent } from '../shared/theme-customizer.component';
import { HeaderComponent } from '../shared/header.component';
import { FooterComponent } from '../shared/footer.component';

declare var Chart: any;

type DashboardView = 'overview' | 'practice' | 'history' | 'profile' | 'theme-settings' | 'results-summary';

@Component({
  selector: 'app-candidate-dashboard',
  standalone: true,
  imports: [CommonModule, InterviewComponent, ChatbotComponent, DatePipe, ReactiveFormsModule, ConfirmationDialogComponent, ThemeCustomizerComponent, HeaderComponent, FooterComponent],
  templateUrl: './candidate-dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CandidateDashboardComponent implements OnInit, AfterViewInit, OnDestroy {
  authService = inject(AuthService);
  interviewService = inject(InterviewService);
  themeService = inject(ThemeService);
  private location = inject(Location);
  private fb: FormBuilder = inject(FormBuilder);
  private router: Router = inject(Router);

  @ViewChild('performanceChart', { static: false }) performanceChart!: ElementRef<HTMLCanvasElement>;
  private chartInstance: any;

  view = signal<DashboardView>('overview');
  isLoadingView = signal(false);
  
  userSessions = computed(() => {
    const user = this.authService.currentUser();
    if (!user) return [];
    return this.interviewService.getSessions()
      .filter(s => s.userId === user.id)
      .sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime());
  });

  expandedResultId = signal<string | null>(null);
  expandedQuestionDetails = signal<string | null>(null);

  isPracticing = signal(false);
  isUserMenuOpen = signal(false);

  jobTitleFilter = signal<string>('');
  categoryFilter = signal<string>('');
  experienceFilter = signal<string>('');
  typeFilter = signal<string>('');

  availableTemplates = computed(() => {
    const allTemplates = this.interviewService.getInterviewTemplates();
    const userCompany = this.authService.currentUser()?.company;
    return allTemplates.filter(t => !t.company || t.company === userCompany);
  });
  
  uniqueJobTitles = computed(() => [...new Set(this.availableTemplates().map(t => t.jobTitle))]);
  uniqueCategories = computed(() => [...new Set(this.availableTemplates().map(t => t.category))]);
  uniqueExperienceLevels = computed(() => [...new Set(this.availableTemplates().map(t => t.experienceLevel))]);
  uniqueTypes = computed(() => [...new Set(this.availableTemplates().map(t => t.type))]);

  filteredTemplates = computed(() => {
    const templates = this.availableTemplates();
    const jobTitle = this.jobTitleFilter().toLowerCase();
    const category = this.categoryFilter().toLowerCase();
    const experience = this.experienceFilter();
    const type = this.typeFilter();

    return templates.filter(template => 
      (!jobTitle || template.jobTitle.toLowerCase().includes(jobTitle)) &&
      (!category || template.category.toLowerCase().includes(category)) &&
      (!experience || template.experienceLevel === experience) &&
      (!type || template.type === type)
    );
  });

  completedSessions = computed(() => this.userSessions().filter(s => s.completedAt));
  averageScore = computed(() => {
    const sessions = this.completedSessions();
    if (sessions.length === 0) return 0;
    const total = sessions.reduce((sum, s) => sum + (s.overallScore || 0), 0);
    return total / sessions.length;
  });
  highestScore = computed(() => {
    const sessions = this.completedSessions();
    if (sessions.length === 0) return 0;
    return Math.max(...sessions.map(s => s.overallScore || 0));
  });

  showLogoutConfirm = signal(false);

  profileForm = this.fb.group({
    name: ['', Validators.required],
    fatherName: [''],
    dob: [''],
    cnic: [''],
    mobile: [''],
    photoUrl: ['']
  });
  isEditingProfile = signal(false);
  profileUpdateStatus = signal<{ message: string, type: 'success' | 'error' } | null>(null);

  lastCompletedSessionId = signal<string | null>(null);
  lastCompletedSession = computed(() => {
      const sessionId = this.lastCompletedSessionId();
      if (!sessionId) return null;
      return this.interviewService.getSessions().find(s => s.id === sessionId);
  });
  sessionResults = computed(() => {
      const sessionId = this.expandedResultId() || this.lastCompletedSessionId();
      if (!sessionId) return [];
      return this.interviewService.getResults().filter(r => r.sessionId === sessionId);
  });
  
  sessionVerdict = computed(() => {
      const score = this.lastCompletedSession()?.overallScore;
      if (score === undefined) return { text: 'Processing', color: 'text-text-muted'};
      if (score >= 8) return { text: 'Passed', color: 'text-emerald-400' };
      if (score >= 5) return { text: 'Average', color: 'text-cyan-400' };
      return { text: 'Failed', color: 'text-purple-400' };
  });
  
  constructor() {
     effect(() => {
      this.completedSessions();
      this.themeService.mode();
      const isLoading = this.isLoadingView();

      if (!isLoading && this.view() === 'overview' && this.performanceChart?.nativeElement) {
        this.destroyChart();
        this.createChart();
      }
    });

    effect(() => {
      const user = this.authService.currentUser();
      if (user) {
        this.profileForm.patchValue({
          name: user.name,
          fatherName: user.fatherName,
          dob: user.dob,
          cnic: user.cnic,
          mobile: user.mobile,
          photoUrl: user.photoUrl,
        });
      }
    });
  }
  
  ngOnInit(): void {}

  ngAfterViewInit(): void {
    if (this.view() === 'overview') {
       this.createChart();
    }
  }

  ngOnDestroy(): void {
    this.destroyChart();
  }
  
  startPractice(templateId: string): void {
    const user = this.authService.currentUser();
    if (!user) {
        alert("You must be logged in to start an interview.");
        return;
    }
    const sessionId = this.interviewService.startInterviewSession(templateId, user);
    if (sessionId) {
        this.isPracticing.set(true);
    } else {
        alert("Could not start interview. The selected template has no questions.");
    }
  }

  handleInterviewCompletion(sessionId: string | null): void {
    if (sessionId) {
      this.lastCompletedSessionId.set(sessionId);
      this.setView('results-summary');
    }
    this.isPracticing.set(false);
  }

  private destroyChart(): void {
    if (this.chartInstance) {
      this.chartInstance.destroy();
      this.chartInstance = null;
    }
  }

  private createChart(): void {
    if (!this.performanceChart?.nativeElement || this.completedSessions().length === 0) return;
    
    setTimeout(() => {
      if (!this.performanceChart?.nativeElement) return;
      const ctx = this.performanceChart.nativeElement.getContext('2d');
      if (!ctx) return;
      
      const isLightTheme = this.themeService.mode() === 'light';
      const gridColor = isLightTheme ? 'rgba(0, 0, 0, 0.1)' : 'rgba(255, 255, 255, 0.1)';
      const labelColor = isLightTheme ? '#374151' : '#E5E7EB';
      
      const reversedSessions = [...this.completedSessions()].reverse();
      const labels = reversedSessions.map((_, i) => `Session ${i + 1}`);
      const overallScores = reversedSessions.map(s => s.overallScore || 0);

      const createGradient = (color: string) => {
        const gradient = ctx.createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, `${color}60`);
        gradient.addColorStop(1, `${color}10`);
        return gradient;
      };

      this.chartInstance = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: 'Overall Score',
            data: overallScores,
            backgroundColor: createGradient('#22D3EE'),
            borderColor: '#22D3EE',
            borderWidth: 2,
            pointBackgroundColor: '#FFFFFF',
            pointBorderColor: '#22D3EE',
            pointHoverBackgroundColor: '#22D3EE',
            pointHoverBorderColor: '#FFFFFF',
            tension: 0.4,
            fill: true,
          }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            y: { beginAtZero: true, max: 10, grid: { color: gridColor }, ticks: { color: labelColor } },
            x: { grid: { display: false }, ticks: { color: labelColor } },
          },
        },
      });
    }, 10);
  }

  confirmLogout(): void {
    this.showLogoutConfirm.set(true);
    this.isUserMenuOpen.set(false);
  }
  
  logout(confirmed: boolean): void {
    if(confirmed) this.authService.logout();
    this.showLogoutConfirm.set(false);
  }

  goBack(): void { this.location.back(); }
  
  setView(newView: DashboardView): void {
    this.isUserMenuOpen.set(false);
    if (this.view() === newView) return;
    
    this.isLoadingView.set(true);
    this.isPracticing.set(false);
    this.isEditingProfile.set(false);

    setTimeout(() => {
      this.view.set(newView);
      this.isLoadingView.set(false);
    }, 300);
  }
  
  toggleResultExpansion(sessionId: string): void {
    this.expandedResultId.update(current => current === sessionId ? null : sessionId);
  }

  toggleQuestionDetails(questionId: string): void {
    this.expandedQuestionDetails.update(current => (current === questionId ? null : questionId));
  }
  
  onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = () => {
        this.profileForm.patchValue({ photoUrl: reader.result as string });
      };
      reader.readAsDataURL(input.files[0]);
    }
  }

  async saveProfile(): Promise<void> {
    if (this.profileForm.invalid) {
      this.profileUpdateStatus.set({ message: 'Please ensure all required fields are filled correctly.', type: 'error'});
      return;
    }
    const success = await this.authService.updateUserProfile(this.profileForm.value);
    this.profileUpdateStatus.set({ message: success ? 'Profile updated successfully!' : 'Failed to update profile.', type: success ? 'success' : 'error'});
    if (success) this.isEditingProfile.set(false);
    setTimeout(() => this.profileUpdateStatus.set(null), 3000);
  }
  
  onJobTitleFilterChange(event: Event): void { this.jobTitleFilter.set((event.target as HTMLInputElement).value); }
  onCategoryFilterChange(event: Event): void { this.categoryFilter.set((event.target as HTMLInputElement).value); }
  onExperienceFilterChange(event: Event): void { this.experienceFilter.set((event.target as HTMLSelectElement).value); }
  onTypeFilterChange(event: Event): void { this.typeFilter.set((event.target as HTMLSelectElement).value); }
  resetFilters(): void {
    this.jobTitleFilter.set('');
    this.categoryFilter.set('');
    this.experienceFilter.set('');
    this.typeFilter.set('');
  }
  
  getScoreColorClass(score: number): string {
    if (score >= 8) return 'text-emerald-400';
    if (score >= 5) return 'text-cyan-400';
    return 'text-purple-400';
  }
  
  viewCertificate(sessionId: string): void {
    this.router.navigate(['/certificate', sessionId]);
  }
}