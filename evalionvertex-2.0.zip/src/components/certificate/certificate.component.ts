import { ChangeDetectionStrategy, Component, computed, inject, signal, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonModule, DatePipe, Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
// FIX: Import InterviewSession as it contains the status property needed for the certificate.
import { InterviewService, InterviewResult, InterviewSession } from '../../services/interview.service';
import { AuthService } from '../../services/auth.service';
import { HeaderComponent } from '../shared/header.component';

declare var html2canvas: any;
declare var jspdf: any;

@Component({
  selector: 'app-certificate',
  standalone: true,
  templateUrl: './certificate.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, DatePipe, HeaderComponent],
})
export class CertificateComponent implements OnInit {
  private route: ActivatedRoute = inject(ActivatedRoute);
  private router: Router = inject(Router);
  private interviewService: InterviewService = inject(InterviewService);
  private location: Location = inject(Location);
  authService = inject(AuthService);

  @ViewChild('certificateContent', { static: false }) certificateContent!: ElementRef<HTMLDivElement>;

  sessionId = signal<string | null>(null);
  // FIX: Add a signal to hold the session object, which contains the approval status.
  session = signal<InterviewSession | null>(null);
  sessionResults = signal<InterviewResult[]>([]);
  
  sessionDetails = computed(() => {
    const results = this.sessionResults();
    // FIX: Get the session from its signal to access properties like 'status'.
    const currentSession = this.session();
    if (results.length === 0 || !currentSession) return null;
    
    const firstResult = results[0];
    const totalScore = results.reduce((sum, r) => sum + r.evaluation.score, 0);
    const overallScore = totalScore / results.length;
    
    return {
      candidateName: firstResult.userName,
      jobTitle: firstResult.jobTitle,
      date: firstResult.answeredOn,
      overallScore: overallScore,
      // FIX: Use status from the session object, not the result object.
      status: currentSession.status
    };
  });

  qrCodeUrl = computed(() => {
    if (!this.sessionId()) return '';
    // In a real app, this would be the public URL of the verification page.
    const verificationUrl = `${window.location.origin}${window.location.pathname}#/certificate/${this.sessionId()}`;
    return `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(verificationUrl)}`;
  });

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('sessionId');
    this.sessionId.set(id);
    if (id) {
      // FIX: Fetch the session object corresponding to the session ID.
      const sessionForId = this.interviewService.getSessions().find(s => s.id === id);
      this.session.set(sessionForId || null);

      const allResults = this.interviewService.getResults();
      const resultsForSession = allResults.filter(r => r.sessionId === id);
      if (resultsForSession.length > 0 && sessionForId) {
        // Security check: ensure the logged-in user is either the candidate or an admin
        const currentUser = this.authService.currentUser();
        const isOwner = currentUser?.name === resultsForSession[0].userName;
        const isAdmin = currentUser?.role === 'super-admin' || currentUser?.role === 'content-manager';

        if (isOwner || isAdmin) {
           // FIX: Check the status from the session object, not the result object.
           if (sessionForId.status === 'approved') {
               this.sessionResults.set(resultsForSession);
           } else {
                alert('This certificate is not yet approved or has been rejected.');
                this.router.navigate(['/candidate']);
           }
        } else {
          alert('You do not have permission to view this certificate.');
          this.router.navigate(['/candidate']);
        }
      } else {
        alert('Certificate not found.');
        this.router.navigate(['/candidate']);
      }
    }
  }

  printCertificate(): void {
    window.print();
  }
  
  async downloadCertificate(): Promise<void> {
    const certificate = this.certificateContent.nativeElement;
    if (certificate) {
        try {
            const canvas = await html2canvas(certificate, { 
                scale: 2, 
                useCORS: true,
                backgroundColor: getComputedStyle(document.documentElement).getPropertyValue('--color-bg').trim() || '#010A1A',
            });
            const imgData = canvas.toDataURL('image/png');
            const { jsPDF } = jspdf;
            
            const pdf = new jsPDF({
                orientation: 'landscape',
                unit: 'mm',
                format: 'a4'
            });
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = pdf.internal.pageSize.getHeight();
            const ratio = canvas.width / canvas.height;
            
            let imgWidth = pdfWidth - 20; // with margin
            let imgHeight = imgWidth / ratio;

            if (imgHeight > pdfHeight - 20) {
                imgHeight = pdfHeight - 20;
                imgWidth = imgHeight * ratio;
            }

            const x = (pdfWidth - imgWidth) / 2;
            const y = (pdfHeight - imgHeight) / 2;

            pdf.addImage(imgData, 'PNG', x, y, imgWidth, imgHeight);
            pdf.save(`EvalionVertex-Certificate-${this.sessionId()}.pdf`);
        } catch (e) {
            console.error('Error downloading certificate:', e);
            alert('Could not download certificate. Please try again.');
        }
    }
  }

  goBack(): void {
    this.location.back();
  }
}