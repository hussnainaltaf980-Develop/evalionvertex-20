import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService, UserRole } from '../../services/auth.service';
import { HeaderComponent } from '../shared/header.component';
import { FooterComponent } from '../shared/footer.component';
import { GeminiService } from '../../services/gemini.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink, HeaderComponent, FooterComponent],
  templateUrl: './login.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent {
  private fb: FormBuilder = inject(FormBuilder);
  private authService = inject(AuthService);
  private router: Router = inject(Router);
  private geminiService = inject(GeminiService);

  loginState = signal<'login' | 'forgot-password' | 'reset-sent'>('login');

  loginForm = this.fb.group({
    email: ['candidate@example.com', [Validators.required, Validators.email]],
    password: ['password123', Validators.required],
    rememberMe: [true]
  });

  forgotPasswordForm = this.fb.group({
    email: ['', [Validators.required, Validators.email]]
  });

  // FIX: Widen type to include 'admin' for the login UI toggle.
  activeRole = signal<UserRole | 'admin'>('candidate');
  showPassword = signal(false);
  loginError = signal<string | null>(null);
  apiError = this.geminiService.error;
  currentYear = new Date().getFullYear();

  constructor() {
    // This logic is now handled by the publicGuard.
  }

  // FIX: Widen type to include 'admin' to match the signal and logic.
  setActiveRole(role: UserRole | 'admin'): void {
    this.activeRole.set(role);
    this.loginError.set(null);
    if (role === 'admin') {
        this.loginForm.patchValue({ email: 'admin@example.com' });
    } else {
        this.loginForm.patchValue({ email: 'candidate@example.com' });
    }
  }

  togglePasswordVisibility(): void {
    this.showPassword.update(value => !value);
  }
  
  forgotPassword(): void {
    this.loginState.set('forgot-password');
    this.loginError.set(null);
  }

  requestPasswordReset(): void {
    if (this.forgotPasswordForm.invalid) {
      this.loginError.set('Please enter a valid email address.');
      return;
    }
    this.loginError.set(null);
    // In a real app, this is where you'd call a service to send the reset email.
    // For this mock-up, we'll just switch the state.
    this.loginState.set('reset-sent');
  }

  backToLogin(): void {
    this.loginState.set('login');
    this.loginError.set(null);
  }

  onSubmit(): void {
    if (this.loginForm.invalid) {
      this.loginError.set('Please enter valid credentials.');
      return;
    }

    this.loginError.set(null);
    const { email, password } = this.loginForm.value;

    const success = this.authService.login(email!, password!, this.activeRole());

    if (!success) {
      this.loginError.set('Login failed. Please check your credentials.');
    }
    // On success, the auth service handles navigation
  }
}
