import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './footer.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FooterComponent {
  currentYear = signal(new Date().getFullYear());
  contactEmail = signal('expert@officialhussnaintechcreat.site');
  contactPhone = signal('+923028808488');
  address = signal('Daska Sialkot Pakistan');
}
