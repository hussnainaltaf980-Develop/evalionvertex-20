import { ChangeDetectionStrategy, Component, computed, inject, signal, ViewChild, ElementRef, effect, OnDestroy, OnInit, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GeminiService, EvaluationResult } from '../../services/gemini.service';
import { InterviewService, InterviewResult } from '../../services/interview.service';
import { AuthService } from '../../services/auth.service';
import { HeaderComponent } from '../shared/header.component';

type InterviewState = 'not-started' | 'permission-check' | 'camera-check' | 'get-ready' | 'preparing-question' | 'in-progress' | 'evaluating' | 'completed' | 'error';
type PermissionState = 'prompt' | 'granted' | 'denied';
type RecordingStatus = 'idle' | 'recording';

interface StoredAnswer {
  videoBlob: Blob;
  transcript: string;
}

declare var webkitSpeechRecognition: any;

@Component({
  selector: 'app-interview',
  standalone: true,
  templateUrl: './interview.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, FormsModule, HeaderComponent]
})
export class InterviewComponent implements OnDestroy, OnInit {
  geminiService = inject(GeminiService);
  interviewService = inject(InterviewService);
  authService = inject(AuthService);

  @Output() interviewComplete = new EventEmitter<string | null>();
  sessionId = signal<string | null>(null);

  @ViewChild('videoPreview', { static: false }) videoPreview!: ElementRef<HTMLVideoElement>;
  @ViewChild('audioVisualizerCanvas', { static: false }) audioVisualizerCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('qualityCheckCanvas', { static: false }) qualityCheckCanvas!: ElementRef<HTMLCanvasElement>;

  interviewState = signal<InterviewState>('permission-check');
  currentYear = new Date().getFullYear();
  
  evaluationProgressSteps = signal<{text: string, status: 'in-progress' | 'done' | 'pending'}[]>([]);
  evaluationStatusMessage = signal('Initializing AI analysis...');
  private statusInterval: any;

  cameraPermission = signal<PermissionState>('prompt');
  micPermission = signal<PermissionState>('prompt');
  
  recordingStatus = signal<RecordingStatus>('idle');
  mediaRecorder: MediaRecorder | null = null;
  recordedBlob = signal<Blob | null>(null);
  private recordedChunks: Blob[] = [];

  readonly maxRecordingTime = 120;
  timeRemaining = signal(this.maxRecordingTime);
  private timerInterval: any;
  timesUp = signal(false);

  getReadyCountdown = signal(3);
  private getReadyInterval: any;

  formattedTimeRemaining = computed(() => {
    const totalSeconds = this.timeRemaining();
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  });

  timerProgress = computed(() => ((this.maxRecordingTime - this.timeRemaining()) / this.maxRecordingTime) * 100);

  videoStream = signal<MediaStream | null>(null);
  facingMode = signal<'user' | 'environment'>('user');
  hasMultipleCameras = signal(false);
  isMicMuted = signal(false);

  audioStream = signal<MediaStream | null>(null);
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private dataArray: Uint8Array | null = null;
  private animationFrameId: number | null = null;

  isListening = signal(false);
  private speechRecognition: any | null = null;
  finalTranscript = signal('');
  interimTranscript = signal('');
  userAnswer = computed(() => this.finalTranscript() + this.interimTranscript());

  lightQuality = signal<'good' | 'low' | 'checking'>('checking');
  audioQuality = signal<'good' | 'low' | 'muted' | 'checking'>('checking');
  private qualityCheckInterval: any;

  // FIX: Use the 'activeQuestions' signal from the service instead of a non-existent method.
  private questions = computed(() => this.interviewService.activeQuestions());
  private storedAnswers = new Map<number, StoredAnswer>();

  currentQuestionIndex = signal(0);
  currentQuestion = computed(() => this.questions()[this.currentQuestionIndex()]);
  
  progress = computed(() => {
    const totalQuestions = this.questions().length;
    return totalQuestions > 0 ? (this.currentQuestionIndex() / totalQuestions) * 100 : 0;
  });

  errorMessage = this.geminiService.error;
  showErrorDetails = signal(false);

  errorDetails = computed(() => {
    // ... (error details logic remains the same)
    const msg = this.errorMessage();
    if (!msg) return { reason: 'An unknown error occurred.', suggestion: 'Please try again or restart the interview.', icon: 'unknown' };
    const lowerMsg = msg.toLowerCase();
    if (lowerMsg.includes('permission') && lowerMsg.includes('denied')) return { reason: 'Media Access Denied.', suggestion: 'Camera and microphone access is required. Please enable it in your browser\'s site settings for this page and then retry.', icon: 'cam-denied' };
    if (lowerMsg.includes('not found')) return { reason: 'Device Not Found.', suggestion: 'No camera or microphone was detected. Please ensure your devices are properly connected.', icon: 'cam-not-found' };
    if (lowerMsg.includes('in use')) return { reason: 'Device In Use.', suggestion: 'Your camera or microphone is being used by another application. Please close it and try again.', icon: 'cam-in-use' };
    if (lowerMsg.includes('api key')) return { reason: 'Configuration Error.', suggestion: 'The application is not configured correctly to communicate with the AI service. Please contact support.', icon: 'api-key' };
    if (lowerMsg.includes('network')) return { reason: 'Network Connection Error.', suggestion: 'A connection to the AI service could not be established. Please check your internet connection and retry.', icon: 'network' };
    if (lowerMsg.includes('busy')) return { reason: 'AI Service Overloaded.', suggestion: 'The AI service is currently experiencing high demand. Please wait and retry.', icon: 'service-busy' };
    return { reason: 'An Unexpected Error Occurred.', suggestion: 'Please try again. If the problem persists, try restarting the interview.', icon: 'unknown' };
  });

  canRetry = computed(() => !['api-key'].includes(this.errorDetails().icon));

  constructor() {
    effect(() => {
      const stream = this.videoStream();
      if (this.videoPreview?.nativeElement) this.videoPreview.nativeElement.srcObject = stream;
    });
    effect(() => {
      if (this.recordingStatus() === 'recording' && this.audioVisualizerCanvas?.nativeElement) this.setupAudioVisualization();
      else this.stopAudioVisualization();
    });
    effect(() => {
      if (!this.speechRecognition) return;
      if (this.recordingStatus() === 'recording' && !this.isListening()) this.speechRecognition.start();
      else if (this.recordingStatus() === 'idle' && this.isListening()) this.speechRecognition.stop();
    });
    effect(() => {
      if (this.interviewState() === 'camera-check' && this.qualityCheckCanvas?.nativeElement) this.startQualityChecks();
      else this.stopQualityChecks();
    });
  }
  
  ngOnInit(): void {
    this.setupSpeechRecognition();
  }

  ngOnDestroy(): void {
    this.stopMediaStreams();
    if (this.speechRecognition) this.speechRecognition.abort();
    clearInterval(this.statusInterval);
    clearInterval(this.getReadyInterval);
    this.interviewService.exitFocusMode();
  }
  
  private setupAudioAnalyser(stream: MediaStream): void {
    // ... (audio analyser setup remains the same)
    if (this.audioContext?.state !== 'closed') {
        this.audioContext?.close().catch(e => console.error('Error closing previous audio context:', e));
    }
    try {
        this.audioContext = new AudioContext();
        const source = this.audioContext.createMediaStreamSource(stream);
        this.analyser = this.audioContext.createAnalyser();
        this.analyser.fftSize = 256;
        const bufferLength = this.analyser.frequencyBinCount;
        this.dataArray = new Uint8Array(bufferLength);
        source.connect(this.analyser);
    } catch (e) {
        console.error('Failed to create AudioContext for analysis', e);
        this.audioContext = null;
        this.analyser = null;
    }
  }

  private setupAudioVisualization(): void {
    if (this.animationFrameId === null) this.drawVisualization();
  }

  private drawVisualization(): void {
    // ... (draw visualization remains the same)
    if (!this.analyser || !this.dataArray || !this.audioVisualizerCanvas?.nativeElement || this.recordingStatus() !== 'recording') {
          this.stopAudioVisualization();
          return;
      }
      this.animationFrameId = requestAnimationFrame(() => this.drawVisualization());
      this.analyser.getByteFrequencyData(this.dataArray);
      const canvas = this.audioVisualizerCanvas.nativeElement;
      const canvasCtx = canvas.getContext('2d');
      if (!canvasCtx) return;
      const { width, height } = canvas;
      const primaryAccent = getComputedStyle(document.documentElement).getPropertyValue('--color-primary-accent').trim();
      const secondaryAccent = getComputedStyle(document.documentElement).getPropertyValue('--color-secondary-accent').trim();
      canvasCtx.clearRect(0, 0, width, height);
      const bufferLength = this.analyser.frequencyBinCount;
      const barWidth = (width / bufferLength) * 1.5;
      let x = 0;
      const gradient = canvasCtx.createLinearGradient(0, 0, 0, height);
      gradient.addColorStop(0, primaryAccent);
      gradient.addColorStop(0.5, secondaryAccent);
      gradient.addColorStop(1, primaryAccent);
      canvasCtx.fillStyle = gradient;
      for (let i = 0; i < bufferLength; i++) {
          const barHeight = this.dataArray[i] / 2.5;
          canvasCtx.fillRect(x, height - (barHeight > 2 ? barHeight : 2), barWidth, barHeight > 2 ? barHeight : 2);
          x += barWidth + 2;
      }
  }

  private stopAudioVisualization(): void {
    // ... (stop visualization remains the same)
      if (this.animationFrameId !== null) {
        cancelAnimationFrame(this.animationFrameId);
        this.animationFrameId = null;
      }
      if (this.audioVisualizerCanvas?.nativeElement) {
        const canvas = this.audioVisualizerCanvas.nativeElement;
        const canvasCtx = canvas.getContext('2d');
        canvasCtx?.clearRect(0, 0, canvas.width, canvas.height);
      }
  }

  private setupSpeechRecognition(): void {
    // ... (speech recognition setup remains the same)
    if (!('webkitSpeechRecognition' in window)) return;
    this.speechRecognition = new webkitSpeechRecognition();
    this.speechRecognition.continuous = true;
    this.speechRecognition.interimResults = true;
    this.speechRecognition.lang = 'en-US';
    this.speechRecognition.onstart = () => this.isListening.set(true);
    this.speechRecognition.onresult = (event: any) => {
      let final = '', interim = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) final += event.results[i][0].transcript;
        else interim += event.results[i][0].transcript;
      }
      this.finalTranscript.update(val => val + final);
      this.interimTranscript.set(interim);
    };
    this.speechRecognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      if (event.error !== 'no-speech' && event.error !== 'aborted') {
          this.geminiService.error.set(`Speech recognition error: ${event.error}.`);
          this.interviewState.set('error');
      }
      this.isListening.set(false);
    };
    this.speechRecognition.onend = () => this.isListening.set(false);
  }

  startInterview(): void {
    if (this.questions().length === 0) {
      this.geminiService.error.set("No interview questions available.");
      this.interviewState.set('error');
      return;
    }
    const user = this.authService.currentUser();
    const template = this.interviewService.activeTemplate();
    if (user && template) {
      const newSessionId = this.interviewService.startInterviewSession(template.id, user);
      this.sessionId.set(newSessionId);
    }
    this.currentQuestionIndex.set(0);
    this.resetAnswerState();
    this.geminiService.error.set(null);
    this.showErrorDetails.set(false);
    this.interviewState.set('permission-check');
  }
  
  async requestPermissions(): Promise<void> {
    this.interviewState.set('camera-check');
    const stream = await this.initializeVideoStream(true);
    if (!stream) this.interviewState.set('error');
  }

  confirmCameraReady(): void {
    this.stopQualityChecks();
    this.interviewState.set('get-ready');
    this.getReadyCountdown.set(3);
    this.getReadyInterval = setInterval(() => {
        this.getReadyCountdown.update(val => {
            if (val > 1) return val - 1;
            clearInterval(this.getReadyInterval);
            this.beginFirstQuestion();
            return 0;
        });
    }, 1000);
  }

  async beginFirstQuestion(): Promise<void> {
      this.interviewState.set('preparing-question');
      await this.prepareForQuestion();
  }

  private stopMediaStreams() {
    this.videoStream()?.getTracks().forEach(track => track.stop());
    this.videoStream.set(null);
    this.audioStream()?.getTracks().forEach(track => track.stop());
    this.audioStream.set(null);
    if (this.videoPreview?.nativeElement) this.videoPreview.nativeElement.srcObject = null;
    if (this.animationFrameId !== null) cancelAnimationFrame(this.animationFrameId);
    this.animationFrameId = null;
    if (this.audioContext?.state !== 'closed') this.audioContext?.close().catch(console.error);
    this.audioContext = null;
    this.stopQualityChecks();
  }
  
  private resetAnswerState(): void {
    if (this.mediaRecorder?.state !== 'inactive') this.mediaRecorder?.stop();
    if (this.isListening()) this.speechRecognition?.abort();
    clearInterval(this.timerInterval);
    this.timeRemaining.set(this.maxRecordingTime);
    this.timesUp.set(false);
    this.recordingStatus.set('idle');
    this.recordedBlob.set(null);
    this.recordedChunks = [];
    this.finalTranscript.set('');
    this.interimTranscript.set('');
  }

  private handleMediaError(err: any, type: 'media') {
    console.error(`Error accessing ${type}:`, err);
    let errorMessage = `Could not access the ${type}.`;
    if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        this.cameraPermission.set('denied');
        this.micPermission.set('denied');
    }
    this.geminiService.error.set(err.message || err.name);
    this.interviewState.set('error');
  }

  private async initializeVideoStream(forCheck: boolean = false): Promise<MediaStream | null> {
    try {
      this.stopMediaStreams();
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: this.facingMode() }, audio: true });
      this.isMicMuted.set(false);
      this.videoStream.set(stream);
      this.cameraPermission.set('granted');
      this.micPermission.set('granted');
      this.audioStream.set(stream);
      this.setupAudioAnalyser(stream);
      this.checkCameraDevices();
      
      if (!forCheck) {
          this.interviewState.set('in-progress');
      }

      return stream;
    } catch (err: any) {
      this.handleMediaError(err, 'media');
      return null;
    }
  }
  
  async prepareForQuestion(): Promise<void> {
    this.resetAnswerState();
    await this.initializeVideoStream();
  }

  startRecording(): void {
    if (!this.videoStream()) {
      console.error("Stream not available to start recording.");
      this.geminiService.error.set('Stream not available to start recording. Please ensure camera access is allowed and retry.');
      this.interviewState.set('error');
      return;
    }
    this.interviewService.enterFocusMode();
    this.mediaRecorder = new MediaRecorder(this.videoStream()!, { mimeType: 'video/webm' });
    this.mediaRecorder.ondataavailable = (event) => { if (event.data.size > 0) this.recordedChunks.push(event.data); };
    this.mediaRecorder.start();
    this.recordingStatus.set('recording');
    this.timesUp.set(false);
    this.timeRemaining.set(this.maxRecordingTime);
    this.timerInterval = setInterval(() => {
      this.timeRemaining.update(time => {
        if (time > 1) return time - 1;
        this.timesUp.set(true);
        this.stopRecording();
        return 0;
      });
    }, 1000);
  }

  stopRecording(): void {
    if (!this.mediaRecorder || this.mediaRecorder.state === 'inactive') return;
    clearInterval(this.timerInterval);
    this.mediaRecorder.onstop = () => {
        this.interviewService.exitFocusMode();
        const blob = new Blob(this.recordedChunks, { type: 'video/webm' });
        this.recordedBlob.set(blob);
        this.recordingStatus.set('idle');
        this.mediaRecorder = null;
    };
    this.mediaRecorder.stop();
  }

  async saveAndProceed(): Promise<void> {
    const currentBlob = this.recordedBlob();
    if (!currentBlob) return;

    this.storedAnswers.set(this.currentQuestionIndex(), {
      videoBlob: currentBlob,
      transcript: this.finalTranscript()
    });

    if (this.currentQuestionIndex() < this.questions().length - 1) {
      this.currentQuestionIndex.update(i => i + 1);
      this.interviewState.set('preparing-question');
      await this.prepareForQuestion();
    } else {
      await this.finishAndEvaluateSession();
    }
  }

  private blobToDataURL(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
  }

  async finishAndEvaluateSession(): Promise<void> {
    this.stopMediaStreams();
    this.interviewState.set('evaluating');
    this.startEvaluationProgress();
  
    const resultsToSubmit: Omit<InterviewResult, 'answeredOn'>[] = [];
    const template = this.interviewService.activeTemplate()!;
    const user = this.authService.currentUser()!;
  
    for (let i = 0; i < this.questions().length; i++) {
        this.evaluationProgressSteps.update(steps => {
            const newSteps = [...steps];
            if(newSteps[i]) newSteps[i].status = 'in-progress';
            if(newSteps[i-1]) newSteps[i-1].status = 'done';
            return newSteps;
        });
  
        const answer = this.storedAnswers.get(i);
        if (answer) {
            const videoUrl = await this.blobToDataURL(answer.videoBlob);
            const result = await this.geminiService.evaluateAnswer(this.questions()[i], { text: answer.transcript, videoBlob: answer.videoBlob });
            
            if (result) {
                resultsToSubmit.push({
                    sessionId: this.sessionId()!,
                    questionId: `${template.id}-${i}`,
                    questionText: this.questions()[i],
                    transcript: answer.transcript,
                    evaluation: result,
                    videoUrl: videoUrl,
                    userName: user.name,
                    jobTitle: template.jobTitle,
                    category: template.category,
                    experienceLevel: template.experienceLevel,
                    company: template.company
                });
            } else {
                this.interviewState.set('error');
                clearInterval(this.statusInterval);
                return;
            }
        }
    }
    
    this.evaluationProgressSteps.update(steps => steps.map(s => ({...s, status: 'done' as const})));
    this.evaluationStatusMessage.set('Compiling overall session feedback...');
    
    const overallEval = resultsToSubmit.length > 0
      ? await this.geminiService.evaluateOverallSession(resultsToSubmit as any)
      : null;

    this.interviewService.completeInterviewSession(this.sessionId()!, resultsToSubmit, overallEval);
    
    clearInterval(this.statusInterval);
    this.interviewState.set('completed');
  }

  private startEvaluationProgress(): void {
    // FIX: Explicitly type the return value of the map function to prevent the 'status' property from being widened to a generic 'string'.
    const steps = this.questions().map((q, i): { text: string; status: 'in-progress' | 'done' | 'pending' } => ({
      text: `Evaluating Question ${i + 1}...`,
      status: i === 0 ? 'in-progress' : 'pending'
    }));
    this.evaluationProgressSteps.set(steps);
    this.evaluationStatusMessage.set('Our AI is reviewing your responses...');
    // Simplified interval, as progress is now step-based.
    const messages = ['Analyzing vocal tone...', 'Cross-referencing key concepts...', 'Finalizing the detailed report...'];
    let messageIndex = 0;
    this.statusInterval = setInterval(() => {
      this.evaluationStatusMessage.set(messages[messageIndex]);
      messageIndex = (messageIndex + 1) % messages.length;
    }, 3000);
  }

  async skipQuestion(): Promise<void> {
    if (this.currentQuestionIndex() < this.questions().length - 1) {
      this.currentQuestionIndex.update(i => i + 1);
      this.interviewState.set('preparing-question');
      await this.prepareForQuestion();
    } else {
      await this.finishAndEvaluateSession();
    }
  }

  async retryLastQuestion(): Promise<void> {
    this.geminiService.error.set(null);
    this.showErrorDetails.set(false);
    this.interviewState.set('preparing-question');
    await this.prepareForQuestion();
  }
  
  toggleErrorDetails(): void { this.showErrorDetails.update(v => !v); }
  private startQualityChecks(): void { this.qualityCheckInterval = setInterval(() => { this.checkLightQuality(); this.checkAudioQuality(); }, 1000); }
  private stopQualityChecks(): void { if (this.qualityCheckInterval) clearInterval(this.qualityCheckInterval); }
  private checkLightQuality(): void {
    // ... (light quality check logic remains the same)
    if (!this.qualityCheckCanvas?.nativeElement || !this.videoPreview?.nativeElement || !this.videoPreview.nativeElement.videoWidth) return;
    const canvas = this.qualityCheckCanvas.nativeElement;
    const video = this.videoPreview.nativeElement;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const { data } = imageData;
    let brightnessSum = 0;
    for (let i = 0; i < data.length; i += 4) {
      brightnessSum += 0.2126 * data[i] + 0.7152 * data[i+1] + 0.0722 * data[i+2];
    }
    const avgBrightness = brightnessSum / (data.length / 4);
    this.lightQuality.set(avgBrightness > 70 ? 'good' : 'low');
  }
  private checkAudioQuality(): void {
    // ... (audio quality check logic remains the same)
    if (!this.analyser || !this.dataArray) { this.audioQuality.set('checking'); return; }
    if(this.isMicMuted()) { this.audioQuality.set('muted'); return; }
    this.analyser.getByteFrequencyData(this.dataArray);
    const average = this.dataArray.reduce((acc, val) => acc + val, 0) / this.dataArray.length;
    if (average > 10) this.audioQuality.set('good');
    else if (average > 0) this.audioQuality.set('low');
    else this.audioQuality.set('muted');
  }
  async checkCameraDevices(): Promise<void> {
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      this.hasMultipleCameras.set(devices.filter(d => d.kind === 'videoinput').length > 1);
    } catch (e) { console.error('Could not enumerate devices:', e); }
  }
  toggleCameraFacingMode(): void {
    this.facingMode.update(current => current === 'user' ? 'environment' : 'user');
    this.initializeVideoStream(true);
  }
}