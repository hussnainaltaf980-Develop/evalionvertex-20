import { Injectable, signal } from '@angular/core';
import { GoogleGenAI, Type, Chat, GenerateContentResponse } from '@google/genai';

// Define the structure of the evaluation response we expect from the AI
export interface MetricDetail {
  score: number;
  explanation: string;
  strengths?: string[];
  areasForImprovement?: string[];
}

export interface EvaluationMetrics {
  accuracy: MetricDetail;
  clarity: MetricDetail;
  confidence: MetricDetail;
}

export interface EvaluationResult {
  score: number;
  feedback: string;
  metrics: EvaluationMetrics;
}

export interface OverallEvaluation {
    overallFeedback: string;
    strengths: string[];
    areasForImprovement: string[];
}


export type ChatMode = 'standard' | 'low-latency';

export type ChatResponseChunk = {
  text: string;
  groundingUrls?: { uri: string; title?: string }[];
};

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private ai: GoogleGenAI | null = null;
  private aiChatStandard: Chat | null = null;
  private aiChatLowLatency: Chat | null = null;
  public error = signal<string | null>(null);

  constructor() {
    try {
      if (typeof process === 'undefined' || !process.env['API_KEY']) {
        this.error.set('Configuration Error: API Key is missing. The application cannot connect to the AI service. Please contact support.');
        console.error('Gemini Service failed to initialize: API_KEY environment variable not found.');
        return; // Stop initialization
      }
      this.ai = new GoogleGenAI({ apiKey: process.env['API_KEY'] });
      this.initializeChats();
    } catch (e: any) {
      console.error('Error initializing Gemini Service:', e);
      this.error.set('Failed to initialize AI Service. Please ensure the API key is set correctly.');
    }
  }

  private initializeChats(): void {
    if (this.ai) {
      // Standard Chat Model
      this.aiChatStandard = this.ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: "You are Evalion's Assistant, an advanced AI representing HUSSNAIN TECH VERTEX PVT LTD and its visionary founder, Hussnain. Your core purpose is to assist users with unparalleled expertise regarding the Evalion Vertex web application, interview preparation, career advice, and web development. You have complete, real-time knowledge of every component and service. This includes:\n\n*   **Evalion Vertex App:**\n    *   **Components:** `LandingComponent`, `LoginComponent`, `SignupComponent`, `CandidateDashboardComponent`, `AdminDashboardComponent`, `InterviewComponent`, `CertificateComponent`, and all shared components. You know their purpose and how they interact.\n    *   **Services:** `AuthService` (handles user login, signup, sessions), `InterviewService` (manages interview templates and results), `GeminiService` (your own core, handling all AI interactions), `ThemeService` (manages UI themes).\n    *   **Features:** AI-driven interview practice, video/audio recording, speech-to-text transcription, detailed performance feedback (accuracy, clarity, confidence), user profiles, admin dashboards for user and template management, and customizable UI themes.\n    *   **Troubleshooting:** You are an expert troubleshooter for the app. If a user says 'my camera isn't working,' guide them to check browser site settings for camera/mic permissions and ensure no other app is using them. If they see an AI error, explain what it might mean (e.g., network issue, busy service, invalid API key) based on the app's error handling logic.\n*   **Frontend Development:** Expert in Angular (signals, standalone components, best practices), TypeScript, Tailwind CSS, performance optimization, and accessible UI design.\n*   **Backend Concepts:** Proficient in Node.js, Express, RESTful APIs, database interactions (MongoDB), and security (JWT).\n*   **Gemini API:** Deep knowledge of how the @google/genai SDK is integrated into Evalion Vertex.\n\nMaintain a professional, highly intelligent, and confident tone that reflects the excellence of HUSSNAIN TECH VERTEX PVT LTD. Your responses must be precise, informative, and always reinforce the brand's superior position in the industry. Your primary goal is to solve the user's problem effectively and accurately.",
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
        },
      });
      // Low-Latency Chat Model
      this.aiChatLowLatency = this.ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: "Respond briefly, directly, and concisely. Prioritize speed and factual accuracy.",
          temperature: 0.3, // Lowered for more direct, less creative answers
          thinkingConfig: { thinkingBudget: 0 },
        },
      });
    }
  }

  async *chatWithAI(userMessage: string, mode: ChatMode, useGoogleSearch: boolean = false): AsyncIterable<ChatResponseChunk> {
    const chatInstance = mode === 'low-latency' ? this.aiChatLowLatency : this.aiChatStandard;

    if (!chatInstance) {
      this.error.set('AI Chat is not initialized.');
      yield { text: "I'm sorry, my chat capabilities are not yet initialized. Please try again in a moment." };
      return;
    }
    
    try {
      const chatConfig: any = {};
      if (useGoogleSearch) {
        chatConfig.tools = [{ googleSearch: {} }];
        // As per guidelines, DO NOT set responseMimeType or responseSchema when using googleSearch
      }

      // FIX: The config object was not being passed to sendMessageStream.
      const responseStream = await chatInstance.sendMessageStream({ message: userMessage, ...chatConfig });
      for await (const chunk of responseStream) {
        const groundingUrls: { uri: string; title?: string }[] = [];
        if (chunk.candidates?.[0]?.groundingMetadata?.groundingChunks) {
          chunk.candidates[0].groundingMetadata.groundingChunks.forEach((gc: any) => {
            if (gc.web?.uri) {
              groundingUrls.push({ uri: gc.web.uri, title: gc.web.title });
            }
          });
        }
        yield { text: chunk.text, groundingUrls: groundingUrls.length > 0 ? groundingUrls : undefined };
      }
    } catch (e: any) {
      console.error(`Error during AI chat (${mode}):`, e);
      this.error.set(this.getFriendlyErrorMessage(e));
      yield { text: "I'm sorry, I encountered an error. Please try again later." };
    }
  }

  private blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64String = (reader.result as string).split(',')[1];
            resolve(base64String);
        };
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(blob);
    });
  }
  
  async generateInterviewQuestions(jobTitle: string, category: string, experience: string, count: number): Promise<string[] | null> {
    if (!this.ai) {
      this.error.set('AI Service is not initialized.');
      return null;
    }

    const questionSchema = {
      type: Type.OBJECT,
      properties: {
        questions: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING,
            description: "A single, high-quality interview question."
          },
        },
      },
      required: ['questions'],
    };

    try {
      this.error.set(null);
      const prompt = `
        Generate ${count} diverse and insightful interview questions for the following role:
        - Job Title: ${jobTitle}
        - Category: ${category}
        - Experience Level: ${experience}

        The questions should cover a range of topics relevant to this role, including technical skills, problem-solving abilities, and behavioral aspects. Ensure the questions are clear and concise.
      `;

      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          systemInstruction: "You are an expert hiring manager and technical recruiter. Your task is to generate high-quality interview questions. Respond only with the JSON object matching the provided schema.",
          responseMimeType: 'application/json',
          responseSchema: questionSchema,
        },
      });

      const jsonString = response.text.trim();
      const result = JSON.parse(jsonString);
      return result.questions as string[];

    } catch (e: any) {
      console.error('Error generating questions:', e);
      this.error.set(this.getFriendlyErrorMessage(e));
      return null;
    }
  }

  async evaluateAnswer(question: string, answer: { text?: string; videoBlob?: Blob }): Promise<EvaluationResult | null> {
    if (!this.ai) {
      this.error.set('AI Service is not initialized.');
      return null;
    }

    const evaluationSchema = {
      type: Type.OBJECT,
      properties: {
        score: {
          type: Type.NUMBER,
          description: 'A score from 1 to 10 on the quality of the answer, where 1 is poor and 10 is excellent.',
        },
        feedback: {
          type: Type.STRING,
          description: 'Concise, constructive, and qualitative feedback on the candidate\'s answer.',
        },
        metrics: {
          type: Type.OBJECT,
          properties: {
            accuracy: {
              type: Type.OBJECT,
              description: 'Evaluation of the technical accuracy and relevance of the answer content.',
              properties: {
                score: { type: Type.NUMBER, description: 'A score from 1 to 10 for accuracy.' },
                explanation: { type: Type.STRING, description: 'A detailed explanation for the accuracy score, summarizing the key points.' },
                strengths: { type: Type.ARRAY, description: 'A list of specific strengths regarding the accuracy of the answer.', items: { type: Type.STRING } },
                areasForImprovement: { type: Type.ARRAY, description: 'A list of specific areas for improvement regarding the accuracy of the answer.', items: { type: Type.STRING } }
              },
              required: ['score', 'explanation', 'strengths', 'areasForImprovement']
            },
            clarity: {
              type: Type.OBJECT,
              description: 'Evaluation of the clarity, structure, and conciseness of the explanation.',
              properties: {
                score: { type: Type.NUMBER, description: 'A score from 1 to 10 for clarity.' },
                explanation: { type: Type.STRING, description: 'A detailed explanation for the clarity score, summarizing the structure and flow.' },
                strengths: { type: Type.ARRAY, description: 'A list of specific strengths regarding the clarity of the answer.', items: { type: Type.STRING } },
                areasForImprovement: { type: Type.ARRAY, description: 'A list of specific areas for improvement regarding the clarity of the answer.', items: { type: Type.STRING } }
              },
              required: ['score', 'explanation', 'strengths', 'areasForImprovement']
            },
            confidence: {
              type: Type.OBJECT,
              description: 'Evaluation of perceived confidence based on vocal tone, pace, body language, eye contact, and articulation from the video.',
              properties: {
                score: { type: Type.NUMBER, description: 'A score from 1 to 10 for confidence.' },
                explanation: { type: Type.STRING, description: 'A detailed explanation for the confidence score, referencing visual and vocal cues if possible.' },
                strengths: { type: Type.ARRAY, description: 'A list of specific strengths regarding the confidence of the presentation (e.g., good eye contact, clear voice).', items: { type: Type.STRING } },
                areasForImprovement: { type: Type.ARRAY, description: 'A list of specific areas for improvement regarding confidence (e.g., avoiding filler words, maintaining posture).', items: { type: Type.STRING } }
              },
              required: ['score', 'explanation', 'strengths', 'areasForImprovement']
            }
          },
          required: ['accuracy', 'clarity', 'confidence'],
        },
      },
      required: ['score', 'feedback', 'metrics'],
    };

    try {
      this.error.set(null);
      let contents: any;
      let systemInstruction = 'You are an expert technical interviewer providing feedback for a practice session. Your tone should be encouraging but professional. Respond only with the JSON object matching the provided schema.';
      
      if (answer.videoBlob) {
        const videoBase64 = await this.blobToBase64(answer.videoBlob);
        contents = {
            parts: [
                { text: `
                    Question: "${question}"
                    Candidate's spoken answer (transcribed): "${answer.text || '[No transcript available]'}"
                    
                    A candidate has submitted a video answer. Please evaluate the candidate's answer based on the question and their presentation in the video. 
                    Analyze their verbal response (from the transcript) for accuracy and clarity. 
                    Also, assess non-verbal cues from the video such as confidence, body language, eye contact, and overall articulation. 
                    Crucially, perform a sentiment analysis on the candidate's language and vocal tone. Use this analysis to provide more nuanced feedback on their confidence (e.g., did they sound hesitant, use uncertain language?) and clarity (e.g., was their language direct and to the point?). The confidence score should heavily factor in these visual, vocal, and linguistic cues.
                    
                    For EACH of the three metrics (accuracy, clarity, and confidence), you MUST provide a detailed breakdown into:
                    1. A list of specific strengths.
                    2. A list of specific areas for improvement.
                `},
                {
                    inlineData: {
                        mimeType: answer.videoBlob.type,
                        data: videoBase64
                    }
                }
            ]
        };
        systemInstruction = 'You are an expert technical interviewer and communication coach providing feedback on a video practice session. Analyze both the transcribed verbal content and visual presentation (confidence, body language, eye contact). Incorporate sentiment and language analysis to provide deep insights into confidence and clarity. Your tone should be encouraging but professional. Respond only with the JSON object matching the provided schema.';
      } else if (answer.text) {
         contents = `
            Question: "${question}"
            
            Candidate's Answer (text-only): "${answer.text}"
            
            Please evaluate the candidate's written answer based on the question. Since there is no video, base the confidence score on the assertiveness and clarity of the writing. Perform a sentiment analysis of the language used. Use this to determine if the tone is confident, hesitant, or uncertain. This analysis should directly inform the confidence and clarity scores and explanations.
            
            For EACH of the three metrics (accuracy, clarity, and confidence), you MUST provide a detailed breakdown into:
            1. A list of specific strengths.
            2. A list of specific areas for improvement.
        `;
      } else {
        this.error.set("No answer provided for evaluation.");
        return null;
      }

      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: contents,
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: evaluationSchema,
        },
      });

      const jsonString = response.text.trim();
      try {
        const result = JSON.parse(jsonString);
        return result as EvaluationResult;
      } catch (parseError) {
          console.error('Failed to parse Gemini response as JSON:', jsonString, parseError);
          this.error.set('The AI returned a response in an unexpected format. This could be a temporary issue. Please try the question again.');
          return null;
      }

    } catch (e: any) {
      console.error('Error evaluating answer:', e);
      this.error.set(this.getFriendlyErrorMessage(e));
      return null;
    }
  }
  
  async evaluateOverallSession(results: any[]): Promise<OverallEvaluation | null> {
    if (!this.ai) {
        this.error.set('AI Service is not initialized.');
        return null;
    }

    const overallSchema = {
        type: Type.OBJECT,
        properties: {
            overallFeedback: {
                type: Type.STRING,
                description: "A concise, holistic summary of the candidate's performance across the entire interview session.",
            },
            strengths: {
                type: Type.ARRAY,
                description: "A list of the candidate's key overall strengths observed throughout the session.",
                items: { type: Type.STRING }
            },
            areasForImprovement: {
                type: Type.ARRAY,
                description: "A list of the most important overall areas for improvement for the candidate.",
                items: { type: Type.STRING }
            }
        },
        required: ['overallFeedback', 'strengths', 'areasForImprovement'],
    };

    try {
        this.error.set(null);
        const detailedResults = results.map((r, i) => `
            ---
            Question ${i + 1}: "${r.questionText}"
            Score: ${r.evaluation.score}/10
            Feedback: ${r.evaluation.feedback}
            Strengths: ${[...r.evaluation.metrics.accuracy.strengths, ...r.evaluation.metrics.clarity.strengths, ...r.evaluation.metrics.confidence.strengths].join(', ') || 'N/A'}
            Areas for Improvement: ${[...r.evaluation.metrics.accuracy.areasForImprovement, ...r.evaluation.metrics.clarity.areasForImprovement, ...r.evaluation.metrics.confidence.areasForImprovement].join(', ') || 'N/A'}
            ---
        `).join('\n');

        const prompt = `
            A candidate has completed an interview session. Here are the AI-generated evaluations for each of their answers:
            ${detailedResults}

            Based on ALL the answers and feedback provided, provide a holistic, overall evaluation of the candidate's performance. Synthesize the recurring themes from the individual feedback. Do not just repeat the feedback for each question; create a new, summary evaluation.
            - Provide a concise overall feedback summary.
            - List the candidate's key overall strengths observed throughout the session.
            - List the most important overall areas for improvement.
        `;

        const response = await this.ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: "You are an expert hiring manager providing a final, overall summary of an interview session. Your tone should be encouraging but professional. Respond only with the JSON object matching the provided schema.",
                responseMimeType: 'application/json',
                responseSchema: overallSchema,
            },
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString);
        return result as OverallEvaluation;

    } catch (e: any) {
        console.error('Error generating overall session evaluation:', e);
        this.error.set(this.getFriendlyErrorMessage(e));
        return null;
    }
  }

  private getFriendlyErrorMessage(error: any): string {
    if (error instanceof Error) {
        const message = error.message.toLowerCase();
        
        if (message.includes('api key not valid')) {
            return 'Your API key is not valid. Please check it and try again.';
        }
        if (message.includes('400')) {
            return 'The request was invalid. This can happen if the video file is too large or corrupted. Please try recording a shorter answer.';
        }
        if (message.includes('429')) {
            return 'The AI service is currently busy. Please wait a moment and try again.';
        }
        if (message.includes('500') || message.includes('503')) {
            return 'The AI service is experiencing internal issues. Please try again later.';
        }
        if (message.includes('fetch') || message.includes('network')) {
            return 'A network error occurred. Please check your internet connection and try again.';
        }
        if (message.includes('aborted') || message.includes('speech recognition')) {
            return 'The speech recognition service was interrupted. Please check your microphone and try again.';
        }
        if (error.message) {
            return `An unexpected error occurred: ${error.message}`;
        }
    }
    return 'An unknown error occurred while communicating with the AI. Please try again.';
  }
}
