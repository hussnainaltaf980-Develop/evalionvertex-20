import { Injectable, signal, effect, computed } from '@angular/core';
import { EvaluationResult, OverallEvaluation } from './gemini.service';
import { User } from './auth.service';

export type InterviewTemplateType = 'technical' | 'behavioral' | 'situational' | 'general';
export type SessionStatus = 'pending' | 'approved' | 'rejected';

export interface InterviewQuestion {
  id: string;
  text: string;
}

export interface InterviewTemplate {
  id:string;
  jobTitle: string;
  category: string;
  experienceLevel: string;
  questions: string[];
  createdAt: string; // ISO string date
  type: InterviewTemplateType;
  company?: string;
  authorId?: string;
  authorName?: string;
}

export interface InterviewSession {
    id: string;
    userId: string;
    userName: string;
    templateId: string;
    jobTitle: string;
    company?: string;
    status: SessionStatus;
    overallScore?: number;
    startedAt: string; // ISO string date
    completedAt?: string; // ISO string date
    overallFeedback?: string;
    overallStrengths?: string[];
    overallAreasForImprovement?: string[];
}

export interface InterviewResult {
  sessionId: string;
  questionId: string;
  questionText: string;
  transcript: string;
  evaluation: EvaluationResult;
  answeredOn: string; // ISO string date
  userName: string;
  jobTitle: string;
  category: string;
  experienceLevel: string;
  company?: string;
  videoUrl: string; // Data URL for the recorded video
}

export interface EvaluationFeedback {
  sessionId: string;
  questionId: string;
  rating: number; // 1-5
  comment: string;
  timestamp: string;
}

const seniorSoftwareEngineerTemplate: InterviewTemplate = {
  id: 'template_senior_swe',
  jobTitle: 'Senior Software Engineer',
  category: 'Software Engineering',
  experienceLevel: 'Senior',
  createdAt: new Date().toISOString(),
  type: 'technical',
  company: 'HussnainTechVertex Pvt Ltd.',
  questions: [
    "Describe a complex software system you have designed or significantly contributed to. What were the major architectural decisions and trade-offs you made?",
    "How do you approach mentoring junior engineers and promoting best practices within a team?",
    "Explain the principles of SOLID design. Provide an example of how you have applied the 'Single Responsibility Principle' in a real-world project.",
    "Discuss your experience with microservices. What are the benefits and drawbacks of this architectural style, and how do you handle challenges like data consistency and service discovery?",
    "How would you design a scalable and resilient API rate-limiting system?"
  ]
};

const generatedSeniorSoftwareEngineerTemplate: InterviewTemplate = {
  id: 'template_senior_swe_generated',
  jobTitle: 'Senior Software Engineer',
  category: 'Software Engineering',
  experienceLevel: 'Senior',
  createdAt: new Date().toISOString(),
  type: 'technical',
  company: 'HussnainTechVertex Pvt Ltd.',
  questions: [
    "Describe the most complex system you've architected. What were the key technical challenges and the trade-offs you made?",
    "Walk me through your process for diagnosing and resolving a major performance bottleneck in a production application.",
    "How do you approach mentoring junior engineers and promoting best practices like code reviews and unit testing within a team?",
    "Explain the CAP theorem and how it applies to distributed system design. Provide an example from your experience.",
    "Design a highly available and scalable URL shortening service. Detail the API, data model, and strategies for handling high traffic.",
    "Discuss your experience with microservices. What are the biggest challenges you've faced regarding data consistency and inter-service communication?",
    "How do you ensure code quality and manage technical debt in a large, long-lived codebase?",
    "Describe a time you led a significant refactoring effort. What was the motivation, what was your strategy, and what was the outcome?",
    "What is your approach to system observability? What are the key metrics, logs, and traces you would want for a critical service?",
    "Talk about a time you had a strong technical disagreement with a peer or manager. How did you handle it and what was the resolution?"
  ]
};

const midLevelFullStackTemplate: InterviewTemplate = {
  id: 'template_mid_fullstack',
  jobTitle: 'Full Stack Developer',
  category: 'Software Engineering',
  experienceLevel: 'Mid-Level',
  createdAt: new Date().toISOString(),
  type: 'technical',
  company: 'HussnainTechVertex Pvt Ltd.',
  questions: [
    "Explain the event loop in Node.js. How does it handle asynchronous operations?",
    "What is the difference between SQL and NoSQL databases? Provide an example of when you would choose one over the other.",
    "Describe your process for building a RESTful API. What are the key principles you follow?",
    "How do you ensure security in a web application? Discuss topics like XSS, CSRF, and SQL injection.",
    "What are Angular Interceptors and for what purposes have you used them?",
    "Explain the concept of state management on the frontend. What solutions have you used (e.g., NgRx, services with signals/subjects) and what are their pros and cons?",
    "Describe your experience with containerization using Docker. How does it help in development and deployment?",
    "What is CI/CD? Describe a CI/CD pipeline you have worked with.",
    "How do you optimize a web application for performance? Discuss both frontend and backend strategies.",
    "You've been tasked with building a real-time chat feature. What technologies and architecture would you consider?"
  ]
};

const juniorFrontendDeveloperTemplate: InterviewTemplate = {
  id: 'template_junior_frontend',
  jobTitle: 'Junior Frontend Developer',
  category: 'Web Development',
  experienceLevel: 'Entry-Level',
  createdAt: new Date().toISOString(),
  type: 'technical',
  company: 'Global Tech Inc.',
  questions: [
    "What are the differences between `null` and `undefined` in JavaScript?",
    "Explain the CSS box model and how `box-sizing: border-box;` changes it.",
    "What is 'semantic HTML' and why is it important for accessibility and SEO?",
    "Can you describe what a closure is in JavaScript and provide a simple example?",
    "How would you handle an asynchronous API call in a modern frontend framework like Angular, React, or Vue?"
  ]
};

const devOpsEngineerTemplate: InterviewTemplate = {
  id: 'template_mid_devops',
  jobTitle: 'DevOps Engineer',
  category: 'Infrastructure',
  experienceLevel: 'Mid-Level',
  createdAt: new Date().toISOString(),
  type: 'technical',
  company: 'HussnainTechVertex Pvt Ltd.',
  questions: [
    "Explain the concept of Infrastructure as Code (IaC) and describe your experience with tools like Terraform or CloudFormation.",
    "What is a CI/CD pipeline? Walk me through the stages of a typical pipeline you have built or managed.",
    "Describe the differences between containers (e.g., Docker) and virtual machines. When would you choose one over the other?",
    "How do you handle secrets management in your infrastructure and applications?",
    "What monitoring and logging tools are you familiar with, and how do you use them to ensure system health and reliability?",
    "Explain the role of Kubernetes in a modern infrastructure. What are some core components like Pods, Services, and Deployments?",
    "You've received an alert that a production service is down. What are your first steps to diagnose and mitigate the issue?"
  ]
};

const initialDefaultTemplate: InterviewTemplate = {
  id: 'template_default',
  jobTitle: 'General Tech Practice',
  category: 'General',
  experienceLevel: 'Entry-Level',
  createdAt: new Date().toISOString(),
  type: 'general',
  questions: [
    "Can you explain the difference between `let`, `const`, and `var` in JavaScript?",
    "What is the purpose of the `async` and `await` keywords in TypeScript?",
    "Describe the concept of dependency injection in Angular.",
    "What are Angular Signals and how do they improve change detection?",
    "Explain the 'box model' in CSS."
  ]
};

const INITIAL_TEMPLATES = [seniorSoftwareEngineerTemplate, generatedSeniorSoftwareEngineerTemplate, midLevelFullStackTemplate, juniorFrontendDeveloperTemplate, devOpsEngineerTemplate, initialDefaultTemplate];

@Injectable({
  providedIn: 'root'
})
export class InterviewService {
  private readonly TEMPLATES_STORAGE_KEY = 'evalion_templates';
  private readonly SESSIONS_STORAGE_KEY = 'evalion_sessions';
  private readonly RESULTS_STORAGE_KEY = 'evalion_results';
  private readonly FEEDBACK_STORAGE_KEY = 'evalion_evaluation_feedback';

  interviewTemplates = signal<InterviewTemplate[]>([]);
  sessions = signal<InterviewSession[]>([]);
  results = signal<InterviewResult[]>([]);
  evaluationFeedback = signal<EvaluationFeedback[]>([]);
  
  activeQuestions = signal<string[]>([]);
  activeTemplate = signal<InterviewTemplate | null>(null);
  
  isFocusMode = signal<boolean>(false);

  userSessions = computed(() => {
    // This could be used by dashboards to filter sessions for the current user
    // For now, filtering is done in components, which is also fine.
    return [];
  });

  constructor() {
    this.loadFromLocalStorage();

    effect(() => {
      this.saveToLocalStorage(this.TEMPLATES_STORAGE_KEY, this.interviewTemplates());
      this.saveToLocalStorage(this.SESSIONS_STORAGE_KEY, this.sessions());
      this.saveToLocalStorage(this.RESULTS_STORAGE_KEY, this.results());
      this.saveToLocalStorage(this.FEEDBACK_STORAGE_KEY, this.evaluationFeedback());
    });
  }

  enterFocusMode(): void { this.isFocusMode.set(true); }
  exitFocusMode(): void { this.isFocusMode.set(false); }

  getInterviewTemplates(): InterviewTemplate[] { return this.interviewTemplates(); }
  getSessions(): InterviewSession[] { return this.sessions(); }
  getResults(): InterviewResult[] { return this.results(); }
  
  addInterviewTemplate(templateData: Omit<InterviewTemplate, 'id' | 'createdAt' | 'company' | 'authorId' | 'authorName'>, author: User): void {
    const newTemplate: InterviewTemplate = {
      ...templateData,
      id: `template_${Date.now()}`,
      createdAt: new Date().toISOString(),
      company: author.company,
      authorId: author.id,
      authorName: author.name
    };
    this.interviewTemplates.update(current => [newTemplate, ...current]);
  }
  
  deleteInterviewTemplate(id: string): void {
    this.interviewTemplates.update(current => current.filter(t => t.id !== id));
  }
  
  startInterviewSession(templateId: string, user: User): string | null {
    const template = this.interviewTemplates().find(t => t.id === templateId);
    if (template && template.questions.length > 0) {
      this.activeQuestions.set(template.questions);
      this.activeTemplate.set(template);
      const newSession: InterviewSession = {
        id: `session_${Date.now()}`,
        userId: user.id,
        userName: user.name,
        templateId: template.id,
        jobTitle: template.jobTitle,
        company: template.company,
        status: 'pending',
        startedAt: new Date().toISOString(),
      };
      this.sessions.update(sessions => [newSession, ...sessions]);
      return newSession.id;
    }
    this.activeQuestions.set([]);
    this.activeTemplate.set(null);
    return null;
  }
  
  completeInterviewSession(
    sessionId: string, 
    results: Omit<InterviewResult, 'answeredOn'>[], 
    overallEval: OverallEvaluation | null
  ): void {
    const newResults: InterviewResult[] = results.map(result => ({
        ...result,
        answeredOn: new Date().toISOString(),
    }));
    this.results.update(current => [...current, ...newResults]);

    // Update session with overall score, feedback, and completion time
    this.sessions.update(sessions => {
        return sessions.map(session => {
            if (session.id === sessionId) {
                const sessionResults = newResults.filter(r => r.sessionId === sessionId);
                const totalScore = sessionResults.reduce((sum, r) => sum + r.evaluation.score, 0);
                const overallScore = sessionResults.length > 0 ? totalScore / sessionResults.length : 0;
                return { 
                    ...session, 
                    completedAt: new Date().toISOString(), 
                    overallScore: overallScore,
                    overallFeedback: overallEval?.overallFeedback,
                    overallStrengths: overallEval?.strengths,
                    overallAreasForImprovement: overallEval?.areasForImprovement
                };
            }
            return session;
        });
    });
  }
  
  async updateSessionStatus(sessionId: string, status: SessionStatus): Promise<void> {
    await new Promise(r => setTimeout(r, 300)); // Simulate network delay
    this.sessions.update(sessions => 
      sessions.map(s => s.id === sessionId ? { ...s, status } : s)
    );
  }
  
  addEvaluationFeedback(feedback: Omit<EvaluationFeedback, 'timestamp'>): void {
    const newFeedback: EvaluationFeedback = { ...feedback, timestamp: new Date().toISOString() };
    this.evaluationFeedback.update(current => [newFeedback, ...current]);
  }

  private loadFromLocalStorage(): void {
    try {
      // Load Templates
      const storedTemplates = localStorage.getItem(this.TEMPLATES_STORAGE_KEY);
      this.interviewTemplates.set(storedTemplates ? JSON.parse(storedTemplates) : INITIAL_TEMPLATES);

      // Load Sessions
      const storedSessions = localStorage.getItem(this.SESSIONS_STORAGE_KEY);
      this.sessions.set(storedSessions ? JSON.parse(storedSessions) : []);

      // Load Results
      const storedResults = localStorage.getItem(this.RESULTS_STORAGE_KEY);
      this.results.set(storedResults ? JSON.parse(storedResults) : []);
      
      // Load Feedback
      const storedFeedback = localStorage.getItem(this.FEEDBACK_STORAGE_KEY);
      this.evaluationFeedback.set(storedFeedback ? JSON.parse(storedFeedback) : []);

    } catch (e) {
      console.error("Failed to load data from localStorage", e);
      this.interviewTemplates.set(INITIAL_TEMPLATES);
      this.sessions.set([]);
      this.results.set([]);
      this.evaluationFeedback.set([]);
    }
  }

  private saveToLocalStorage(key: string, data: any): void {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error(`Failed to save data to localStorage (key: ${key})`, e);
    }
  }
}