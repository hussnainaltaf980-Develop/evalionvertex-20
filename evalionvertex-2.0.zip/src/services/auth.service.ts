import { Injectable, signal, computed } from '@angular/core';
import { Router } from '@angular/router';
import { inject } from '@angular/core';

export type UserRole = 'candidate' | 'super-admin' | 'content-manager';

export interface User {
  id: string;
  email: string;
  password?: string; // Stored only for mock purposes, never in a real app
  role: UserRole;
  name: string;
  fatherName?: string;
  dob?: string;
  cnic?: string;
  mobile?: string;
  photoUrl?: string; // Will store as data URL (Base64)
  company?: string; // For multi-tenancy (stores companyName for simplicity)
  disabled?: boolean; // New field for user management
  companyName?: string; // Company name for admin roles
  companyLogo?: string; // Base64 or URL for company logo
  companyRegistrationNumber?: string; // Registration number for company
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private router: Router = inject(Router);
  private readonly USERS_STORAGE_KEY = 'evalion_users';
  private readonly SESSION_USER_KEY = 'evalion_session_user';

  // In-memory mock user database
  private users = signal<User[]>([]);

  // Current logged-in user state
  currentUser = signal<User | null>(null);
  
  isAuthenticated = computed(() => !!this.currentUser());
  currentUserRole = computed(() => this.currentUser()?.role ?? null);
  currentUserName = computed(() => this.currentUser()?.name ?? null);
  currentUserEmail = computed(() => this.currentUser()?.email ?? null);


  constructor() {
    this.loadUsersFromStorage();
    
    // Check for saved session on initialization
    const sessionUserJson = localStorage.getItem(this.SESSION_USER_KEY);
    if (sessionUserJson) {
      this.currentUser.set(JSON.parse(sessionUserJson));
    }
  }

  private loadUsersFromStorage(): void {
    try {
        const storedUsers = localStorage.getItem(this.USERS_STORAGE_KEY);
        if (storedUsers) {
            let parsedUsers: User[] = JSON.parse(storedUsers);
            // Ensure default users always exist and update if necessary
            const defaultSuperAdmin: User = { 
              id: 'user_super_admin', email: 'admin@example.com', password: 'password123', role: 'super-admin', name: 'Super Admin', 
              company: 'HussnainTechVertex Pvt Ltd.', companyName: 'HussnainTechVertex Pvt Ltd.', companyRegistrationNumber: 'HTV-001-PK', companyLogo: 'https://picsum.photos/40/40?random=1', disabled: false 
            };
            const defaultContentManager: User = { 
              id: 'user_content_manager', email: 'content@example.com', password: 'password123', role: 'content-manager', name: 'Content Manager', 
              company: 'HussnainTechVertex Pvt Ltd.', companyName: 'HussnainTechVertex Pvt Ltd.', companyRegistrationNumber: 'HTV-001-PK', companyLogo: 'https://picsum.photos/40/40?random=2', disabled: false 
            };
            const defaultCandidate: User = { 
              id: 'user_candidate', email: 'candidate@example.com', password: 'password123', role: 'candidate', name: 'Alex Doe', 
              company: 'Global Tech Inc.', disabled: false 
            };

            let usersToSet = parsedUsers.filter(u => u.id !== defaultSuperAdmin.id && u.id !== defaultContentManager.id && u.id !== defaultCandidate.id);
            
            // Add or update default users
            const existingSuperAdminIndex = usersToSet.findIndex(u => u.id === defaultSuperAdmin.id);
            if (existingSuperAdminIndex !== -1) { usersToSet[existingSuperAdminIndex] = {...usersToSet[existingSuperAdminIndex], ...defaultSuperAdmin}; } else { usersToSet.push(defaultSuperAdmin); }
            
            const existingContentManagerIndex = usersToSet.findIndex(u => u.id === defaultContentManager.id);
            if (existingContentManagerIndex !== -1) { usersToSet[existingContentManagerIndex] = {...usersToSet[existingContentManagerIndex], ...defaultContentManager}; } else { usersToSet.push(defaultContentManager); }

            const existingCandidateIndex = usersToSet.findIndex(u => u.id === defaultCandidate.id);
            if (existingCandidateIndex !== -1) { usersToSet[existingCandidateIndex] = {...usersToSet[existingCandidateIndex], ...defaultCandidate}; } else { usersToSet.push(defaultCandidate); }

            this.users.set(usersToSet);

        } else {
            // Add default users if none exist
            const defaultUsers: User[] = [
                { id: 'user_super_admin', email: 'admin@example.com', password: 'password123', role: 'super-admin', name: 'Super Admin', company: 'HussnainTechVertex Pvt Ltd.', companyName: 'HussnainTechVertex Pvt Ltd.', companyRegistrationNumber: 'HTV-001-PK', companyLogo: 'https://picsum.photos/40/40?random=1', disabled: false },
                { id: 'user_content_manager', email: 'content@example.com', password: 'password123', role: 'content-manager', name: 'Content Manager', company: 'HussnainTechVertex Pvt Ltd.', companyName: 'HussnainTechVertex Pvt Ltd.', companyRegistrationNumber: 'HTV-001-PK', companyLogo: 'https://picsum.photos/40/40?random=2', disabled: false },
                { id: 'user_candidate', email: 'candidate@example.com', password: 'password123', role: 'candidate', name: 'Alex Doe', company: 'Global Tech Inc.', disabled: false }
            ];
            this.users.set(defaultUsers);
            this.persistUsers();
        }
    } catch (e) { console.error('Error loading users from localStorage', e); }
  }

  private persistUsers(): void {
    try {
        localStorage.setItem(this.USERS_STORAGE_KEY, JSON.stringify(this.users()));
    } catch(e) { console.error('Error persisting users to localStorage', e); }
  }

  // Updated signUp to be async
  async signUp(userData: Omit<User, 'id' | 'role' | 'disabled' | 'companyName' | 'companyLogo' | 'companyRegistrationNumber'>): Promise<{ success: boolean, message: string }> {
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network delay

    const existingUser = this.users().find(u => u.email === userData.email);
    if (existingUser) {
        return { success: false, message: 'An account with this email already exists.' };
    }
    const newUser: User = {
        ...userData,
        company: userData.company || 'Unaffiliated',
        id: `user_${crypto.randomUUID()}`,
        role: 'candidate', // All signups are candidates
        disabled: false // New users are active by default
    };
    this.users.update(users => [...users, newUser]);
    this.persistUsers();
    
    // Automatically log in the new user
    this.login(newUser.email, newUser.password!, 'candidate');
    
    return { success: true, message: 'Signup successful!' };
  }

  // New method for admin to create users (asynchronous)
  async createUser(userData: Omit<User, 'id' | 'disabled'>): Promise<{ success: boolean, message: string }> {
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 500));

      const existingUser = this.users().find(u => u.email === userData.email);
      if (existingUser) {
          return { success: false, message: 'An account with this email already exists.' };
      }

      // Validate company details for admin roles
      if ((userData.role === 'super-admin' || userData.role === 'content-manager') &&
          (!userData.companyName || !userData.companyLogo || !userData.companyRegistrationNumber)) {
          return { success: false, message: 'Company name, logo, and registration number are required for this role.' };
      }

      const newUser: User = {
          ...userData,
          id: `user_${crypto.randomUUID()}`,
          disabled: false,
          company: userData.companyName || userData.company || 'Unaffiliated' // Ensure company name is set for non-admins too if provided
      };

      this.users.update(users => [...users, newUser]);
      this.persistUsers();
      
      return { success: true, message: 'User created successfully!' };
  }

  // Updated updateUserProfile to be async
  async updateUserProfile(updatedData: Partial<User>): Promise<boolean> {
    await new Promise(resolve => setTimeout(resolve, 300)); // Simulate network delay

    const currentUser = this.currentUser();
    if (!currentUser) return false;

    const updatedUser = { ...currentUser, ...updatedData };
    this.currentUser.set(updatedUser);
    localStorage.setItem(this.SESSION_USER_KEY, JSON.stringify(updatedUser));
    
    // Update user in the main user list
    this.users.update(users => users.map(u => u.id === updatedUser.id ? updatedUser : u));
    this.persistUsers();

    return true;
  }

  // FIX: Allow 'admin' as a login role type to handle grouped admin logins.
  login(email: string, password: string, role: UserRole | 'admin'): boolean {
    const user = this.users().find(u => u.email === email && u.password === password);
    
    if (user && (user.role === role || (role === 'admin' && (user.role === 'super-admin' || user.role === 'content-manager')))) {
      if (user.disabled) {
        this.currentUser.set(null); // Ensure no disabled user is logged in
        return false; // User is disabled
      }
      this.currentUser.set(user);
      localStorage.setItem(this.SESSION_USER_KEY, JSON.stringify(user));
      
      this.router.navigate([user.role === 'candidate' ? '/candidate' : '/admin']);
      return true;
    }
    return false;
  }

  logout(): void {
    this.currentUser.set(null);
    localStorage.removeItem(this.SESSION_USER_KEY);
    this.router.navigate(['/landing']);
  }

  // Admin-specific methods
  getAllUsers(): User[] {
    return this.users();
  }

  // Updated toggleUserStatus to be async
  async toggleUserStatus(userId: string): Promise<boolean> {
    await new Promise(resolve => setTimeout(resolve, 300)); // Simulate network delay

    let userFound = false;
    this.users.update(users => users.map(user => {
      if (user.id === userId) {
        userFound = true;
        return { ...user, disabled: !user.disabled };
      }
      return user;
    }));
    this.persistUsers();

    // If the currently logged-in user disabled themselves, log them out
    if (this.currentUser()?.id === userId && userFound && this.users().find(u => u.id === userId)?.disabled) {
      this.logout();
    }
    return userFound;
  }

  // Updated updateUserRole to be async
  async updateUserRole(userId: string, newRole: UserRole): Promise<boolean> {
    await new Promise(resolve => setTimeout(resolve, 300)); // Simulate network delay

    const currentUser = this.currentUser();
    // Prevent a super admin from changing their own role.
    if (currentUser?.id === userId && currentUser?.role === 'super-admin') {
      console.warn('Super admin cannot change their own role.');
      return false;
    }

    let userFound = false;
    this.users.update(users => users.map(user => {
      if (user.id === userId) {
        userFound = true;
        return { ...user, role: newRole };
      }
      return user;
    }));

    if (userFound) {
      this.persistUsers();
      // If the currently logged-in user had their role changed, update the session.
      if (currentUser?.id === userId) {
        this.currentUser.update(u => u ? { ...u, role: newRole } : null);
        localStorage.setItem(this.SESSION_USER_KEY, JSON.stringify(this.currentUser()));
      }
    }
    
    return userFound;
  }
}
